package com.example.assignmentsql;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MyDBHelper extends SQLiteOpenHelper {
    private static final String DBName = "sinhvien.db";
    private static final String TABLE_NAME = "sinhvien";
    private static final int VERSION = 1;
    private static final String ID = "_id";
    private static final String NAME = "name";
    private static final String YearBorn = "YearBorn";

    SQLiteDatabase myDB;

    public static String getID() {
        return ID;
    }

    public static String getNAME() {
        return NAME;
    }

    public static String getYearBorn() {
        return YearBorn;
    }

    public MyDBHelper(@Nullable Context context) {
        super(context, DBName, null, VERSION);
    }

    public void openDB() {
        myDB = getWritableDatabase();
    }

    public void closeDB() {
        if (myDB != null && myDB.isOpen()){
            myDB.close();
        }
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String query = "CREATE TABLE " + TABLE_NAME + " (" + ID + " INTEGER PRIMARY KEY, " + NAME + " TEXT NOT NULL, " + YearBorn + " INTEGER NOT NULL)";
        sqLiteDatabase.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }

    public long insertDB(int id, String name, int yearBorn) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID, id);
        contentValues.put(NAME, name);
        contentValues.put(YearBorn, yearBorn);
        return myDB.insert(TABLE_NAME, null, contentValues);
    }

    public long updateDB(int id, String name, int yearBorn) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(ID, id);
        contentValues.put(NAME, name);
        contentValues.put(YearBorn, yearBorn);
        String where = ID + " = " + id;
        return myDB.update(TABLE_NAME, contentValues, where, null);
    }

    public long deleteDB(int id) {
        String where = ID + " = " + id;
        return myDB.delete(TABLE_NAME, where, null);
    }

    public Cursor getAllData() {
        myDB = getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        return myDB.rawQuery(query, null);
    }
}

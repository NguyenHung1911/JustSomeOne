package com.example.assignmentsql;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class listAdapter extends ArrayAdapter<SinhVien> {

    public listAdapter(@NonNull Context context, int resource, @NonNull List<SinhVien> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater layoutInflater = LayoutInflater.from(getContext());
            view = layoutInflater.inflate(R.layout.layout_result, null);
        }

        SinhVien sinhVien = getItem(position);
        if (sinhVien != null) {
            TextView textViewID = view.findViewById(R.id.textViewID);
            textViewID.setText(String.valueOf(sinhVien.getId()));
            TextView textViewName = view.findViewById(R.id.textViewName);
            textViewName.setText(sinhVien.getName());
            TextView textViewYearBorn = view.findViewById(R.id.textViewYearBorn);
            textViewYearBorn.setText(String.valueOf(sinhVien.getYearBorn()));
        }
        return view;
    }
}

package com.example.assignmentsql;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText editTextID, editTextName, editTextYearBorn;
    Button btnInsert, btnUpdate, btnDelete, btnLoadAll;
    ListView listView;
    MyDBHelper myDBHelper;
    listAdapter adapter;
    ArrayList<SinhVien> sinhVienArrayList = new ArrayList<>();
    @Override
    protected void onStart() {
        super.onStart();
        myDBHelper.openDB();
    }

    @Override
    protected void onStop() {
        super.onStop();
        myDBHelper.closeDB();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        anhXa();
        myDBHelper = new MyDBHelper(this);
        adapter = new listAdapter(this, R.layout.activity_main, sinhVienArrayList);
        listView.setAdapter(adapter);
        btnInsert.setOnClickListener(view -> {
            long insertResult = myDBHelper.insertDB(Integer.parseInt(getValue(editTextID)), getValue(editTextName), Integer.parseInt(getValue(editTextYearBorn)));
            if (insertResult == -1) {
                Toast.makeText(this, "Error\nID exist", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Complete", Toast.LENGTH_SHORT).show();
            }
        });

        btnLoadAll.setOnClickListener(view -> {

            Cursor cursor = myDBHelper.getAllData();
//            for (cursor.moveToFirst(); !cursor.isAfterLast(); cursor.moveToNext()) {
//                int id = cursor.getInt(cursor.getColumnIndexOrThrow(MyDBHelper.getID()));
//                String name = cursor.getString(cursor.getColumnIndexOrThrow(MyDBHelper.getNAME()));
//                int yearBorn = cursor.getInt(cursor.getColumnIndexOrThrow(MyDBHelper.getYearBorn()));
//                sinhVienArrayList.add(new SinhVien(id, name, yearBorn));
//            }
//            adapter.notifyDataSetChanged();
//            cursor.close();
            cursorAdapter adapter = new cursorAdapter(MainActivity.this, R.layout.layout_result, cursor, 0);
            listView.setAdapter(adapter);
        });
    }

    public void anhXa() {
        editTextID = findViewById(R.id.editTextID);
        editTextName = findViewById(R.id.editTextName);
        editTextYearBorn = findViewById(R.id.editTextYearBorn);
        btnInsert = findViewById(R.id.btnInsert);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        btnLoadAll = findViewById(R.id.btnLoadAll);
        listView = findViewById(R.id.listView);
    }

    public String getValue(EditText editText) {
        return editText.getText().toString().trim();
    }
}
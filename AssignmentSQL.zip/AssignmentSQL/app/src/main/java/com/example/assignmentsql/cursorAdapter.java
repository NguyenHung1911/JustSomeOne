package com.example.assignmentsql;

import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.widget.ResourceCursorAdapter;
import android.widget.TextView;

public class cursorAdapter extends ResourceCursorAdapter {
    public cursorAdapter(Context context, int layout, Cursor c, int flags) {
        super(context, layout, c, flags);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView textViewID = view.findViewById(R.id.textViewID);
        TextView textViewName = view.findViewById(R.id.textViewName);
        TextView textViewYearBorn = view.findViewById(R.id.textViewYearBorn);
        textViewID.setText(cursor.getString(cursor.getColumnIndexOrThrow(MyDBHelper.getID())));
        textViewName.setText(cursor.getString(cursor.getColumnIndexOrThrow(MyDBHelper.getNAME())));
        textViewYearBorn.setText(cursor.getString(cursor.getColumnIndexOrThrow(MyDBHelper.getYearBorn())));
    }
}

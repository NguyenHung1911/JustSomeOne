package com.example.assignmentsql;

public class SinhVien {
    private int id;
    private String name;
    private int yearBorn;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getYearBorn() {
        return yearBorn;
    }

    public void setYearBorn(int yearBorn) {
        this.yearBorn = yearBorn;
    }

    public SinhVien(int id, String name, int yearBorn) {
        this.id = id;
        this.name = name;
        this.yearBorn = yearBorn;
    }

    public SinhVien() {
    }
}

package com.example.svmc.Adapter;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.svmc.AddActivity;
import com.example.svmc.AlamReceier;
import com.example.svmc.R;
import com.example.svmc.SqliteHelper;
import com.example.svmc.fragment.AllFragment;
import com.example.svmc.fragment.TodayFragment;
import com.example.svmc.model.NhiemVu;

import java.util.ArrayList;
import java.util.Calendar;

public class AdapterNV extends RecyclerView.Adapter<AdapterNV.HomeViewHolder> {
    private ArrayList<NhiemVu> list;
    private IteamListener iteamListener;



    public void setList(ArrayList<NhiemVu> list) {
        this.list = list;
        notifyDataSetChanged();
    }


    public void setIteamListener(IteamListener iteamListener) {
        this.iteamListener = iteamListener;
    }

    public NhiemVu getIteam(int pos) {
        return list.get(pos);
    }

    @NonNull
    @Override
    public HomeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.iteam, parent, false);
        return new HomeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HomeViewHolder holder, int position) {
        NhiemVu it = list.get(position);
        holder.nameNV.setText(it.getName());
        holder.dateNV.setText(it.getDate());
        holder.time.setText(it.getTime());

        if(it.getDate().toString().trim().isEmpty()) {
            holder.tv_quaHan.setVisibility(View.INVISIBLE);
        }
        else {
            Calendar calendar = Calendar.getInstance();

            int dayy = calendar.get(Calendar.DAY_OF_MONTH);
            int monthh = calendar.get(Calendar.MONTH) + 1;
            int yearr = calendar.get(Calendar.YEAR);
            int hourss = calendar.get(Calendar.HOUR_OF_DAY);
            int minutee = calendar.get(Calendar.MINUTE);

            int datee = dayy + monthh * 30 + yearr * 365;
            int timee = hourss * 60 + minutee;

            if (DateToDay(it) < datee) {
                if(it.getTrangThai() == 0) {
                    holder.tv_quaHan.setVisibility(View.VISIBLE);
                }
                else {
                    holder.tv_quaHan.setVisibility(View.INVISIBLE);
                }
            } else if (DateToDay(it) == datee && !it.getTime().toString().trim().isEmpty()) {
                if (TimeToMinute(it) < timee) {
                    if(it.getTrangThai() == 0) {
                        holder.tv_quaHan.setVisibility(View.VISIBLE);
                    }
                    else {
                        holder.tv_quaHan.setVisibility(View.INVISIBLE);
                    }
                }
                else {
                    holder.tv_quaHan.setVisibility(View.INVISIBLE);
                }
            }
            else {
                holder.tv_quaHan.setVisibility(View.INVISIBLE);
            }
        }

        if (it.getTrangThai() == 0) {
            holder.cb.setChecked(false);
        } else {
            holder.cb.setChecked(true);
        }
        holder.cb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(it.getTrangThai() == 0) {
                    it.setTrangThai(1);
                }
                else {
                    it.setTrangThai(0);
                }
                list.set(holder.getAdapterPosition(), it);
                SqliteHelper sql = new SqliteHelper(view.getContext());
                sql.update(it);
                AllFragment.updateUI();
                TodayFragment.updateUI();
            }
        });

        holder.btnre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder alertDialog = new AlertDialog.Builder(view.getContext());

                alertDialog.setTitle("Xác nhận").setMessage("bạn có muốn xóa nhiệm vụ " + it.getName());

                alertDialog.setCancelable(true);

                alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        list.remove(it);
                        SqliteHelper sql = new SqliteHelper(view.getContext());
                        sql.delete(it);
                        AllFragment.updateUI();
                        TodayFragment.updateUI();
                        Toast.makeText(view.getContext(), "Xóa thành công", Toast.LENGTH_SHORT).show();
                        dialog.cancel();

                        //delete notification......................



                        Intent intent = new Intent(view.getContext(), AlamReceier.class);
                        intent.setAction("myAction");
                        intent.putExtra("date", it.getDate());
                        intent.putExtra("time", it.getTime());
                        intent.putExtra("id", it.getId());
                        intent.putExtra("name", it.getName());
                        intent.putExtra("repeat", it.getRepeat());
                        AlarmManager alarmManager =
                                (AlarmManager) view.getContext().getSystemService(Context.ALARM_SERVICE);
//                        NotificationManager notificationManager =
//                                (NotificationManager)view.getContext().getSystemService(Context.NOTIFICATION_SERVICE);
                        PendingIntent pendingIntent = PendingIntent.getBroadcast(view.getContext(), it.getId(),
                                intent, PendingIntent.FLAG_UPDATE_CURRENT);
                       alarmManager.cancel(pendingIntent);
                    }
                });
                alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                AlertDialog alert = alertDialog.create();
                alert.show();




            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class HomeViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView nameNV, dateNV, time;
        private CheckBox cb;
        private Button btnre;
        private TextView tv_quaHan;

        public HomeViewHolder(@NonNull View view) {
            super(view);

            nameNV = view.findViewById(R.id.nameNv);
            dateNV = view.findViewById(R.id.dateNV);
            time = view.findViewById(R.id.timeNV);
            cb = view.findViewById(R.id.cbtrangThai);
            btnre = view.findViewById(R.id.btnremoveNv);
            tv_quaHan = view.findViewById(R.id.tv_quaHan);

            view.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            if (iteamListener != null) {
                iteamListener.onIteamClick(view, getAdapterPosition());
            }
        }
    }

    public interface IteamListener {
        void onIteamClick(View view, int pos);
    }

    public static int DateToDay(NhiemVu nvv) {
        String s = nvv.getDate();
        String[] st = s.split("/");
        int res = Integer.parseInt(st[0]) + Integer.parseInt(st[1]) * 30 +
                Integer.parseInt(st[2]) * 365;
        return res;
    }

    public static int TimeToMinute(NhiemVu nvv) {
        String s = nvv.getTime();
        String[] st = s.split(":");
        int res = Integer.parseInt(st[0]) * 60 + Integer.parseInt(st[1]);
        return res;
    }
}

package com.example.svmc.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.svmc.Adapter.AdapterNV;
import com.example.svmc.R;
import com.example.svmc.SqliteHelper;
import com.example.svmc.UpdateActivity;
import com.example.svmc.model.NhiemVu;

import java.util.ArrayList;

public class NoDayFragment extends Fragment implements AdapterNV.IteamListener {
    private static AdapterNV adapter;
    private static SqliteHelper db;
    private RecyclerView recycler;
    private static ArrayList<NhiemVu> list;
    private static TextView tv, tv_name;
    private static Button btn_search;
    private static Spinner sp1;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_noday, container, false);

        tv = view.findViewById(R.id.soNv);
        sp1 = view.findViewById(R.id.spinner_allstatus);
        tv_name = view.findViewById(R.id.all_nameNv);
        btn_search = view.findViewById(R.id.all_btnsearch);

        recycler = view.findViewById(R.id.recycleViewls);
        db = new SqliteHelper(getContext());
        adapter = new AdapterNV();
        list = getAllListNoDay();
        tv.setText("so nhiem vu: " + list.size());
        adapter.setList(list);
        LinearLayoutManager manager = new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false);
        recycler.setLayoutManager(manager);
        recycler.setHasFixedSize(true);
        recycler.setAdapter(adapter);

        adapter.setIteamListener(this);
        return view;
    }

    @Override
    public void onIteamClick(View view, int pos) {
        Intent intent = new Intent(getActivity(), UpdateActivity.class);
        NhiemVu nv = list.get(pos);
        intent.putExtra("nv", nv);
        startActivity(intent);
    }

    public static ArrayList<NhiemVu> getAllListNoDay() {
        int status = sp1.getSelectedItemPosition();
        ArrayList<NhiemVu> list2 = new ArrayList<>();
        list2 = db.getAllNoDay();
        ArrayList<NhiemVu> list1 = new ArrayList<>();
        if (status == 0) {
            for (NhiemVu nv : list2) {
                list1.add(nv);
            }

        } else if (status == 1) {
            for (NhiemVu nv : list2) {
                if (nv.getTrangThai() != 0) {
                    list1.add(nv);
                }
            }

        } else if (status == 2) {
            for (NhiemVu nv : list2) {
                if (nv.getTrangThai() == 0) {
                    list1.add(nv);
                }
            }

        }
        return list1;
    }


    public static void updateUI() {
        if(list != null) {
            list.clear();
        }
        list.addAll(getAllListNoDay());
        tv.setText("so nhiem vu: " + list.size());
        adapter.notifyDataSetChanged();
    }
}

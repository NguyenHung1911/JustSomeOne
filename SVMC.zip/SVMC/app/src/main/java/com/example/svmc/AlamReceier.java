package com.example.svmc;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import java.util.Date;

public class AlamReceier extends BroadcastReceiver {
    final String CHANNEL_ID = "201";
    @Override
    public void onReceive(Context context, Intent intent) {
        if(intent.getAction().equals("myAction")) {
            String time = (String) intent.getExtras().getSerializable("time");
            String date = (String) intent.getExtras().getSerializable("date");
            String name = (String) intent.getExtras().getSerializable("name");
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                        "Channel 1", NotificationManager.IMPORTANCE_HIGH);
                channel.setDescription("test1");
                notificationManager.createNotificationChannel(channel);
            }

            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                    .setContentTitle(name)
                    .setContentText(date + " " + time)
                    .setSmallIcon(R.drawable.ic_notifications)
                    .setColor(Color.RED)
                    .setCategory(NotificationCompat.CATEGORY_ALARM);
            notificationManager.notify(getNotificationid(), builder.build());

        }
        else if(intent.getAction().equals("myDelete")) {
            String name =  (String) intent.getExtras().getSerializable("name");
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(context.NOTIFICATION_SERVICE);
            notificationManager.cancel(getNotificationid());
        }
    }
    private int getNotificationid() {
        int time = (int) new Date().getTime();
        return time;
    }
}

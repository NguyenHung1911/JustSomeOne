package com.example.svmc.helper;

import android.support.v4.app.Fragment;

import com.example.svmc.ActivityHandWriting;
import com.example.svmc.Adapter.ViewPagerAdapter;
import com.example.svmc.fragment.OCRFragment;

/**
 * Created by SMM on 02-Jan-18.
 */

public class DoodleFragment {


    public static OCRFragment getOCRFragment(){
        ViewPagerAdapter adapter = ActivityHandWriting.adapter;
        Fragment page = adapter.getRegisteredFragment(0);
        return (OCRFragment) page;
    }
}

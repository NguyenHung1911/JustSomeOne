package com.example.svmc.Adapter;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.example.svmc.fragment.AllFragment;
import com.example.svmc.fragment.NoDayFragment;
import com.example.svmc.fragment.TodayFragment;

public class AdapterViewPager extends FragmentPagerAdapter {
    private int pageNumber;
    public AdapterViewPager(@NonNull FragmentManager fm, int behavior) {
        super(fm, behavior);
        this.pageNumber = behavior;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new TodayFragment();
            case 1:
                return new AllFragment();
            case 2:
                return new NoDayFragment();
        }
        return null;
    }

    @Override
    public int getCount() {
        return this.pageNumber;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return "Today";
            case 1:
                return "all";
            case 2:
                return "noday";
        }
        return null;
    }
}

package com.example.svmc;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.svmc.fragment.AllFragment;
import com.example.svmc.fragment.NoDayFragment;
import com.example.svmc.fragment.TodayFragment;
import com.example.svmc.model.NhiemVu;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class UpdateActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText editText_name, editText_date, editText_time;
    private Button bt_Mic_Title, bt_Calender, bt_Time, bt_rmTime, bt_rmDate;
    private FloatingActionButton bt_save;
    private NhiemVu nv;
    private final int REQUEST_CODE_SPEECH_INPUT_UPDATE_TITLE = 101;
    private Spinner sp1;
    private LinearLayout liner_repeat, liner_time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        setContentView(R.layout.activity_update);

        Intent intent = getIntent();
        nv = (NhiemVu) intent.getExtras().getSerializable("nv");

        editText_name = findViewById(R.id.ud_NameNV);
        editText_date = findViewById(R.id.ud_DateNV);
        editText_time = findViewById(R.id.ud_TimeNV);
        bt_save = findViewById(R.id.buttonUpdateFab);
        bt_Mic_Title = findViewById(R.id.ud_micbtTitle);
        bt_Calender = findViewById(R.id.ud_calender);
        bt_Time = findViewById(R.id.ud_clock);
        sp1 = findViewById(R.id.spinner_repeat);
        liner_time = findViewById(R.id.ud_linerTime);
        liner_repeat = findViewById(R.id.ud_linerRepeat);
        bt_rmDate = findViewById(R.id.ud_button_cancel_calender);
        bt_rmTime = findViewById(R.id.ud_button_cancel_time);

        editText_name.setText(nv.getName());
        editText_date.setText(nv.getDate());
        editText_time.setText(nv.getTime());
        sp1.setSelection(nv.getRepeat());
        if(nv.getDate().equals("")) {
            liner_time.setVisibility(View.INVISIBLE);
            liner_repeat.setVisibility(View.INVISIBLE);
        }

        editText_date.setFocusableInTouchMode(false);
        editText_time.setFocusableInTouchMode(false);

        bt_Calender.setOnClickListener(this);
        editText_date.setOnClickListener(this);
        bt_Time.setOnClickListener(this);
        editText_time.setOnClickListener(this);
        bt_save.setOnClickListener(this);
        bt_Mic_Title.setOnClickListener(this);
        bt_rmTime.setOnClickListener(this);
        bt_rmDate.setOnClickListener(this);

    }

    private void promptSpeechInput(int request) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to text");
        try {
            startActivityForResult(intent, request);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(UpdateActivity.this, " " + a.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CODE_SPEECH_INPUT_UPDATE_TITLE: {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    editText_name.setText(result.get(0));
                }
                break;
            }
            default:
                throw new IllegalStateException("Unexpected value: " + requestCode);
        }
    }

    @Override
    public void onClick(View v) {
        if (v == bt_Calender || v == editText_date) {
            int day, month, year;

            String date = editText_date.getText().toString().trim();
            if (!date.isEmpty()) {
                String[] st = date.split("/");
                day = Integer.parseInt(st[0]);
                month = Integer.parseInt(st[1]) - 1;
                year = Integer.parseInt(st[2]);
            } else {
                Calendar calendar = Calendar.getInstance();

                day = calendar.get(Calendar.DAY_OF_MONTH);
                month = calendar.get(Calendar.MONTH);
                year = calendar.get(Calendar.YEAR);
            }
            DatePickerDialog dialog = new DatePickerDialog(UpdateActivity.this,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                            month += 1;
                            editText_date.setText(day + "/" + month + "/" + year);
                            liner_time.setVisibility(View.VISIBLE);
                            liner_repeat.setVisibility(View.VISIBLE);
                        }
                    }, year, month, day);
            dialog.show();
        } else if (v == bt_Time || v == editText_time) {
            TimePickerDialog dialog = new TimePickerDialog(UpdateActivity.this,
                    new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {
                            editText_time.setText(hourOfDay + ":" + minute);
                        }
                    }, 12, 15, false);
            dialog.show();
        } else if (v == bt_save) {
            String name, date, time;
            int repeat;
            name = editText_name.getText().toString().trim();
            date = editText_date.getText().toString().trim();
            if(!date.equals("")) {
                time = editText_time.getText().toString().trim();
                repeat = sp1.getSelectedItemPosition();
            }
            else {
                time = "";
                repeat = 0;
            }

            if (name.equals("")) {
                Toast.makeText(UpdateActivity.this, "Yeu cau nhap ten nghiem vu.", Toast.LENGTH_SHORT).show();
            } else {
                nv.setName(name);
                nv.setDate(date);
                nv.setTime(time);
                nv.setRepeat(repeat);

                SqliteHelper sqlite = new SqliteHelper(getApplicationContext());
                sqlite.update(nv);
                AllFragment.updateUI();
                TodayFragment.updateUI();
                NoDayFragment.updateUI();
                Toast.makeText(UpdateActivity.this, "update thanh cong!" + repeat, Toast.LENGTH_SHORT).show();
                finish();
            }
        } else if (v == bt_Mic_Title) {
            promptSpeechInput(REQUEST_CODE_SPEECH_INPUT_UPDATE_TITLE);
        }else if(v == bt_rmDate) {
            editText_date.setText(null);
            liner_time.setVisibility(View.INVISIBLE);
            liner_repeat.setVisibility(View.INVISIBLE);
        }else if(v == bt_rmTime) {
            editText_time.setText(null);
        }
    }
}
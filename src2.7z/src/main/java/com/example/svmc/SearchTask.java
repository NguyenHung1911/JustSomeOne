package com.example.svmc;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.svmc.Adapter.AdapterNV;
import com.example.svmc.fragment.AllFragment;
import com.example.svmc.fragment.TodayFragment;
import com.example.svmc.model.NhiemVu;

import java.util.ArrayList;

public class SearchTask extends AsyncTask<Integer, String, Void> {
    private RecyclerView recyclerView;
    private TextView tv;
    private Context context;
    private String st;
    private ArrayList<NhiemVu> list;
    private AdapterNV adapter;
    private SqliteHelper db;
    private boolean cancel = false;

    public SearchTask(Context context, RecyclerView recyclerView, String st, AdapterNV adapter, TextView tv) {
        this.recyclerView = recyclerView;
        this.context = context;
        this.st = st;
        this.adapter = adapter;
        this.tv = tv;
    }



    @Override
    protected Void doInBackground(Integer... integers) {
        int fr = integers[0];
        if(fr == 0) {
            list = TodayFragment.getAllList();
        }
        else list = AllFragment.getAllList();
        String[] str = st.split(" ");
        for(String s : str) {
            if(cancel) break;
            publishProgress(s);
        }
        return null;
    }

    @Override
    protected void onPreExecute() {

        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(Void unused) {
        super.onPostExecute(unused);
        tv.setText("so nhiem vu: " + list.size());
        adapter.setList(list);
        recyclerView.setAdapter(adapter);
    }

    @Override
    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);
        String s = values[0];
        for(int i = 0; i < list.size(); i++) {
            NhiemVu nv = list.get(i);
            if(!nv.getName().contains(s)) {
                list.remove(i);
                i--;
            }
        }
    }

    public void cancel() {
        this.cancel = true;
    }
}

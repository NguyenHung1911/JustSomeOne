package com.example.todoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import com.example.todoapp.Adapter.ViewPagerAdapter;
import com.example.todoapp.fragment.OCRFragment;
import com.example.todoapp.helper.DoodleFragment;
import com.example.todoapp.helper.LockableViewPager;
import com.github.clans.fab.FloatingActionButton;
import com.github.clans.fab.FloatingActionMenu;
import com.google.android.material.tabs.TabLayout;

public class HandWritingDemo extends AppCompatActivity {

    TabLayout tabLayout;
    LockableViewPager viewPager;

    public static ViewPagerAdapter adapter;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        setContentView(R.layout.activity_hand_writing_demo);

        tabLayout = findViewById(R.id.tabLayoutId);
        viewPager = findViewById(R.id.viewPagerId);
        viewPager.setSwipeable(false); //Modified viewPager to disable swipe in the viewpager.

        tabLayout.setupWithViewPager(viewPager);

        setFragmentToViewPager(); //method to set the fragments in viewpager

    }

    private void setFragmentToViewPager() {
        adapter = new ViewPagerAdapter(getSupportFragmentManager());
        // adapter.addToFragment(paint, "Sketch Note");
        adapter.addToFragment(new OCRFragment(), "Convert to Text");
        viewPager.setAdapter(adapter);
    }
}
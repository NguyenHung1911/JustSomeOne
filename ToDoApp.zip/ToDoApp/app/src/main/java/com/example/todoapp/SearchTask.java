package com.example.todoapp;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.todoapp.Adapter.AdapterNV;
import com.example.todoapp.fragment.AllFragment;
import com.example.todoapp.fragment.TodayFragment;
import com.example.todoapp.model.NhiemVu;

import java.util.ArrayList;

public class SearchTask extends AsyncTask<Void, String, Void> {
    private RecyclerView recyclerView;
    private TextView tv;
    private Context context;
    private String st;
    private ArrayList<NhiemVu> list;
    private AdapterNV adapter;
    private SqliteHelper db;
    private boolean cancel = false;

    public SearchTask(Context context, RecyclerView recyclerView, String st, AdapterNV adapter, TextView tv, ArrayList<NhiemVu> list) {
        this.recyclerView = recyclerView;
        this.context = context;
        this.st = st;
        this.adapter = adapter;
        this.tv = tv;
        this.list = list;
    }



    @Override
    protected Void doInBackground(Void... voids) {
        String[] str = st.split(" ");
        for(String s : str) {
            if(cancel) break;
            publishProgress(s);
        }
        return null;
    }

    @Override
    protected void onPreExecute() {

        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(Void unused) {
        super.onPostExecute(unused);
        tv.setText("so nhiem vu: " + list.size());
        adapter.setList(list);
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onProgressUpdate(String... values) {
        super.onProgressUpdate(values);

        String s = convert(values[0].toLowerCase());
        Log.i("s TAG", s + " " + list.size());
        for(int i = 0; i < list.size(); i++) {
            NhiemVu nv = list.get(i);
            String name = nv.getName();
            Log.i("name TAG", name + " ");
            String tmpNv = convert(name.toLowerCase());
            Log.i("tmp TAG", tmpNv + " ");
            if(!tmpNv.contains(s)) {
                list.remove(i);
                i--;
            }
        }
    }

    public void cancel() {
        this.cancel = true;
    }

    public String convert(String str) {
        str = str.replaceAll("à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ", "a");
        str = str.replaceAll("è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ", "e");
        str = str.replaceAll("ì|í|ị|ỉ|ĩ", "i");
        str = str.replaceAll("ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ", "o");
        str = str.replaceAll("ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ", "u");
        str = str.replaceAll("ỳ|ý|ỵ|ỷ|ỹ", "y");
        str = str.replaceAll("đ", "d");

        str = str.replaceAll("À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ", "A");
        str = str.replaceAll("È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ", "E");
        str = str.replaceAll("Ì|Í|Ị|Ỉ|Ĩ", "I");
        str = str.replaceAll("Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ", "O");
        str = str.replaceAll("Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ", "U");
        str = str.replaceAll("Ỳ|Ý|Ỵ|Ỷ|Ỹ", "Y");
        str = str.replaceAll("Đ", "D");
        return str;
    }
}

package com.example.todoapp.helper;

import androidx.fragment.app.Fragment;

import com.example.todoapp.Adapter.ViewPagerAdapter;
import com.example.todoapp.HandWritingDemo;
import com.example.todoapp.fragment.OCRFragment;

/**
 * Created by SMM on 02-Jan-18.
 */

public class DoodleFragment {


    public static OCRFragment getOCRFragment(){
        ViewPagerAdapter adapter = HandWritingDemo.adapter;
        Fragment page = adapter.getRegisteredFragment(0);
        return (OCRFragment) page;
    }
}

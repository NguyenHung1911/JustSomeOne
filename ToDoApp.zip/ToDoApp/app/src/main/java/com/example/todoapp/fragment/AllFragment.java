package com.example.todoapp.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.todoapp.Adapter.AdapterNV;
import com.example.todoapp.SearchTask;
import com.example.todoapp.SqliteHelper;
import com.example.todoapp.UpdateActivity;
import com.example.todoapp.model.NhiemVu;
import com.example.todoapp.R;

import java.util.ArrayList;

public class AllFragment extends Fragment implements AdapterNV.IteamListener {
    private static AdapterNV adapter;
    private static SqliteHelper db;
    private static RecyclerView recycler;
    private static ArrayList<NhiemVu> list;
    private static TextView tv, tv_name;
    private static Button btn_search;
    private static Spinner sp1;
    private static SearchTask task;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_all, container, false);
        tv = view.findViewById(R.id.all_soNv);
        sp1 = view.findViewById(R.id.spinner_status);
        tv_name = view.findViewById(R.id.all_nameNv);
        btn_search = view.findViewById(R.id.all_btnsearch);

        recycler = view.findViewById(R.id.recycleViewls);
        db = new SqliteHelper(getContext());
        adapter = new AdapterNV();
        list = getAllList();

        tv.setText("so nhiem vu: " + list.size());
        adapter.setList(list);
        LinearLayoutManager manager = new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false);
        recycler.setLayoutManager(manager);
        recycler.setHasFixedSize(true);
        recycler.setAdapter(adapter);

        adapter.setIteamListener(this);

        tv_name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String name = tv_name.getText().toString().trim();
                if(task != null) {
                    task.cancel();
                }
                task = new SearchTask(getContext(), recycler, name, adapter, tv, getAllList());
                task.execute();
            }
        });

        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(list.size() > 0) {
                    list.clear();
                }
                list.addAll(getAllList());
                tv.setText("so nhiem vu: " + list.size());
                adapter.setList(list);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        return view;

    }

    @Override
    public void onIteamClick(View view, int pos) {
        Intent intent = new Intent(getActivity(), UpdateActivity.class);
        NhiemVu nv = adapter.getlist().get(pos);
        intent.putExtra("nv", nv);
        startActivity(intent);
    }

    public static void updateUI() {
        if(list.size() > 0) {
            list.clear();
        }
        list.addAll(getAllListByName());
        tv.setText("so nhiem vu: " + list.size());
        adapter.notifyDataSetChanged();
    }

    public static ArrayList<NhiemVu> getAllList() {
        ArrayList<NhiemVu> list1 = new ArrayList<>();
        ArrayList<NhiemVu> list2 = db.getAll();
        int status = sp1.getSelectedItemPosition();

        if (status == 0) {
            for (NhiemVu nv : list2) {
                    list1.add(nv);
            }

        } else if (status == 1) {
            for (NhiemVu nv : list2) {
                if (nv.getTrangThai() != 0) {
                    list1.add(nv);
                }
            }

        } else if (status == 2) {
            for (NhiemVu nv : list2) {
                if (nv.getTrangThai() == 0) {
                    list1.add(nv);
                }
            }

        }
        return list1;
    }

    public static ArrayList<NhiemVu> getAllListByName() {
        ArrayList<NhiemVu> list1 = new ArrayList<>();
        ArrayList<NhiemVu> list2 = db.getAll();
        int status = sp1.getSelectedItemPosition();

        if (status == 0) {
            for (NhiemVu nv : list2) {
                if(checksearch(nv)){
                    list1.add(nv);
                }
            }

        } else if (status == 1) {
            for (NhiemVu nv : list2) {
                if (nv.getTrangThai() != 0 && checksearch(nv)) {
                    list1.add(nv);
                }
            }

        } else if (status == 2) {
            for (NhiemVu nv : list2) {
                if (nv.getTrangThai() == 0 && checksearch(nv)) {
                    list1.add(nv);
                }
            }

        }
        return list1;
    }

    public static boolean checksearch(NhiemVu nv) {
        String s = tv_name.getText().toString().trim();
        if(s.equals("")){
            return true;
        }
        String name = nv.getName();
        String[] st = s.split(" ");
        for(String str : st) {
            if(!name.contains(str)) {
                return false;
            }
        }
        return true;
    }


}
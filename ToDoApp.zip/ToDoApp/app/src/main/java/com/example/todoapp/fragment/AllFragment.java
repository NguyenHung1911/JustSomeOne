package com.example.todoapp.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.todoapp.Adapter.AdapterNV;
import com.example.todoapp.SearchTask;
import com.example.todoapp.SqliteHelper;
import com.example.todoapp.UpdateActivity;
import com.example.todoapp.model.NhiemVu;
import com.example.todoapp.R;

import java.util.ArrayList;

public class AllFragment extends Fragment implements AdapterNV.IteamListener {
    private static AdapterNV adapter;
    private static SqliteHelper db;
    private static RecyclerView recycler;
    private static ArrayList<NhiemVu> list;
    private static TextView tv, tv_name;
    private static Button btn_search;
    private static Spinner sp1;
    private static SearchTask task;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_all, container, false);
        tv = view.findViewById(R.id.all_soNv);
        sp1 = view.findViewById(R.id.spinner_status);
        tv_name = view.findViewById(R.id.all_nameNv);
        btn_search = view.findViewById(R.id.all_btnsearch);

        recycler = view.findViewById(R.id.recycleViewls);
        db = new SqliteHelper(getContext());
        adapter = new AdapterNV();
        list = getAllList();

        tv.setText("so nhiem vu: " + list.size());
        adapter.setList(list);
        LinearLayoutManager manager = new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false);
        recycler.setLayoutManager(manager);
        recycler.setHasFixedSize(true);
        recycler.setAdapter(adapter);

        adapter.setIteamListener(this);

        tv_name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String name = tv_name.getText().toString().trim();
                if(task != null) {
                    task.cancel();
                }
                task = new SearchTask(getContext(), recycler, name, adapter, tv);
                task.execute(1);
            }
        });

        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                updateUI();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        return view;

    }

    public static String convert(String str) {
        str = str.replaceAll("à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ", "a");
        str = str.replaceAll("è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ", "e");
        str = str.replaceAll("ì|í|ị|ỉ|ĩ", "i");
        str = str.replaceAll("ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ", "o");
        str = str.replaceAll("ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ", "u");
        str = str.replaceAll("ỳ|ý|ỵ|ỷ|ỹ", "y");
        str = str.replaceAll("đ", "d");

        str = str.replaceAll("À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ", "A");
        str = str.replaceAll("È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ", "E");
        str = str.replaceAll("Ì|Í|Ị|Ỉ|Ĩ", "I");
        str = str.replaceAll("Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ", "O");
        str = str.replaceAll("Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ", "U");
        str = str.replaceAll("Ỳ|Ý|Ỵ|Ỷ|Ỹ", "Y");
        str = str.replaceAll("Đ", "D");
        return str;
    }

    @Override
    public void onIteamClick(View view, int pos) {
        Intent intent = new Intent(getActivity(), UpdateActivity.class);
        NhiemVu nv = list.get(pos);
        intent.putExtra("nv", nv);
        startActivity(intent);
    }

    public static void updateUI() {
        if(list.size() > 0) {
            list.clear();
        }
        list.addAll(getAllList());
        tv.setText("so nhiem vu: " + list.size());
        adapter.setList(list);
        recycler.setAdapter(adapter);
    }

    public static ArrayList<NhiemVu> getAllList() {
        ArrayList<NhiemVu> list1 = new ArrayList<>();
        ArrayList<NhiemVu> list2 = db.getAll();
        int status = sp1.getSelectedItemPosition();

        if (status == 0) {
            for (NhiemVu nv : list2) {
                if(checksearch(nv)){
                    list1.add(nv);
                }
            }

        } else if (status == 1) {
            for (NhiemVu nv : list2) {
                if (nv.getTrangThai() != 0 && checksearch(nv)) {
                    list1.add(nv);
                }
            }

        } else if (status == 2) {
            for (NhiemVu nv : list2) {
                if (nv.getTrangThai() == 0 && checksearch(nv)) {
                    list1.add(nv);
                }
            }

        }
        return list1;
    }

    public static boolean checksearch(NhiemVu nv) {
        String s = tv_name.getText().toString().trim();
        if(s.equals("")){
            return true;
        }
        String name = nv.getName();
        String[] st = s.split(" ");
        for(String str : st) {
            if(!name.contains(str)) {
                return false;
            }
        }
        return true;
    }


}
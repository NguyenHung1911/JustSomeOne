# SimpleAndroidNeuralNetworkOCR
Example of handwriting number recognition implementation on Android with Neuroph's NeuralNetwork.

This application implement with few sample of handwriting image. 
To get more accurcy, need to use more handwriting image and more tuning on NeuralNetwork generation.

Example video

[![Example](https://img.youtube.com/vi/2Db6t0mmSZQ/0.jpg)](https://www.youtube.com/watch?v=2Db6t0mmSZQ)

![screenshot_1513396712](https://user-images.githubusercontent.com/466386/34067266-5614e43c-e253-11e7-8cb3-27c31a233bb7.png)

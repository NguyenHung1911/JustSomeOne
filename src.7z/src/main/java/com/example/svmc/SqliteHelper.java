package com.example.svmc;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.svmc.model.NhiemVu;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class SqliteHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "NHIEMVU.db";
    private static final int DATABASE_VERSION = 1;

    public SqliteHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String creatDB = "CREATE TABLE nv(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,date TEXT, " +
                "time TEXT,content TEXT,TrangThai INTEGER)";

        db.execSQL(creatDB);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
    }

    public ArrayList<NhiemVu> getAll() {
        ArrayList<NhiemVu> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String order = "time";
        Cursor rs = db.query("nv", null, null, null, null, null, order);
        while (rs != null && rs.moveToNext()) {
            int id = rs.getInt(0);
            String name = rs.getString(1);
            String date = rs.getString(2);
            String time = rs.getString(3);
            String content = rs.getString(4);
            int trangThai = rs.getInt(5);
            list.add(new NhiemVu(id, name, date, time, content, trangThai));
        }
        SortList(list);
        return list;
    }

    public ArrayList<NhiemVu> getAll(String today) {
        ArrayList<NhiemVu> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String order = "time";
        String whereClause = "date=?";
        String[] whereArgs = {String.valueOf(today)};
        Cursor rs = db.query("nv", null, whereClause, whereArgs, null, null, null);
        while (rs != null && rs.moveToNext()) {
            int id = rs.getInt(0);
            String name = rs.getString(1);
            String date = rs.getString(2);
            String time = rs.getString(3);
            String content = rs.getString(4);
            int trangThai = rs.getInt(5);
            list.add(new NhiemVu(id, name, date, time, content, trangThai));
        }
        SortList(list);
        return list;
    }

    public static void SortList(ArrayList<NhiemVu> list) {
        Collections.sort(list, new Comparator<NhiemVu>() {
            @Override
            public int compare(NhiemVu t1, NhiemVu t2) {
                if(!t1.getDate().equals(t2.getDate())) {
                    return DateToDay(t1) - DateToDay(t2);
                }
                else {
                    return TimeToMinute(t1) - TimeToMinute(t2);
                }
            }
        });
    }

    public static int DateToDay(NhiemVu nvv) {
        String s = nvv.getDate();
        String[] st = s.split("/");
        int res = Integer.parseInt(st[0]) + Integer.parseInt(st[1]) * 30 +
                Integer.parseInt(st[2]) * 365;
        return res;
    }

    public static int TimeToMinute(NhiemVu nvv) {
        String s = nvv.getTime();
        String[] st = s.split(":");
        int res = Integer.parseInt(st[0]) * 60 + Integer.parseInt(st[1]);
        return res;
    }



    public long add(NhiemVu item) {
        ContentValues content = new ContentValues();
        content.put("name", item.getName());
        content.put("date", item.getDate());
        content.put("time", item.getTime());
        content.put("content", item.getContent());
        content.put("trangThai", item.getTrangThai());

        SQLiteDatabase sql = getWritableDatabase();
        return sql.insert("nv", null, content);
    }

    public int update(NhiemVu item) {
        ContentValues content = new ContentValues();
        content.put("name", item.getName());
        content.put("date", item.getDate());
        content.put("time", item.getTime());
        content.put("content", item.getContent());
        content.put("trangThai", item.getTrangThai());

        String whereClause = "id=?";
        String[] whereArgs = {String.valueOf(item.getId())};
        SQLiteDatabase sql = getWritableDatabase();
        return sql.update("nv", content, whereClause, whereArgs);
    }

    public int delete(NhiemVu item) {
        String whereClause = "id=?";
        String[] whereArgs = {String.valueOf(item.getId())};

        SQLiteDatabase sql = getWritableDatabase();
        return sql.delete("nv", whereClause, whereArgs);
    }
}

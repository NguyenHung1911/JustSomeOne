package com.example.svmc;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.svmc.fragment.AllFragment;
import com.example.svmc.fragment.TodayFragment;
import com.example.svmc.model.NhiemVu;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class AddActivity extends AppCompatActivity {
    private EditText name, date, time, content;
    private Button save, cancel, clock, calender, micContent, micTitle;
    private final int REQUEST_CODE_SPEECH_INPUT_ADD_CONTENT = 100;
    private final int REQUEST_CODE_SPEECH_INPUT_ADD_TITLE = 101;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        
        name = findViewById(R.id.add_NameNV);
        date = findViewById(R.id.add_DateNV);
        time = findViewById(R.id.add_TimeNV);
        content = findViewById(R.id.add_ContentNV);
        save = findViewById(R.id.add_savebt);
        cancel = findViewById(R.id.add_cancelbt);
        clock = findViewById(R.id.add_clock);
        calender = findViewById(R.id.add_calender);
        micContent = findViewById(R.id.add_micbtContent);
        micTitle = findViewById(R.id.add_micbtTitle);
        
        date.setEnabled(false);
        time.setEnabled(false);

         /*ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            Intent data = result.getData();
                            content.setText(data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).get(0));
                        }
                    }
                }
        );*/

        calender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();

                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                int year = calendar.get(Calendar.YEAR);
                DatePickerDialog dialog = new DatePickerDialog(AddActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        month += 1;
                        date.setText(day + "/" + month + "/" + year);
                    }
                }, year, month, day);
                dialog.show();
            }
        });

        clock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TimePickerDialog dialog = new TimePickerDialog(AddActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker timePicker,int hourOfDay, int minute) {
                                time.setText(hourOfDay + ":" + minute);
                            }
                        }, 12, 15, false);
                        dialog.show();
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String namenv = name.getText().toString();
                String datenv = date.getText().toString();
                String timenv = time.getText().toString();
                String contentnv = content.getText().toString();

                if (namenv.equals("") || datenv.equals("") || timenv.equals(""))
                Toast.makeText(AddActivity.this, "Yeu cau dien day du cac truong.", Toast.LENGTH_SHORT).show();
                else if (!datenv.matches("[\\d/]+"))
                    Toast.makeText(AddActivity.this, "Du lieu ngay khong hop le.", Toast.LENGTH_SHORT).show();
                else {
                    SqliteHelper sqlite = new SqliteHelper(getApplicationContext());
                    sqlite.add(new NhiemVu(namenv, datenv, timenv, contentnv));
                    AllFragment.updateUI();
                    TodayFragment.updateUI();
                    Toast.makeText(AddActivity.this, "Them thanh cong!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        micContent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               promptSpeechInput(REQUEST_CODE_SPEECH_INPUT_ADD_CONTENT);
                //activityResultLauncher.launch(intent);
            }
        });

        micTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                promptSpeechInput(REQUEST_CODE_SPEECH_INPUT_ADD_TITLE);
            }
        });
    }
    
    private void promptSpeechInput(int request) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to text");
        try {
            startActivityForResult(intent, request);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(AddActivity.this, " " + a.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CODE_SPEECH_INPUT_ADD_CONTENT: {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    content.setText(result.get(0));
                }
                break;
            }
            case REQUEST_CODE_SPEECH_INPUT_ADD_TITLE: {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    name.setText(result.get(0));
                }
                break;
            }
            default:
                throw new IllegalStateException("Unexpected value: " + requestCode);
        }
    }
}
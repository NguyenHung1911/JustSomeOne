package com.example.svmc;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.svmc.fragment.AllFragment;
import com.example.svmc.fragment.NoDayFragment;
import com.example.svmc.fragment.TodayFragment;
import com.example.svmc.model.NhiemVu;
import com.example.svmc.model.Reminder;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class AddActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText name;
    private TextView date, time;
    private Button save, cancel, micTitle, calender, clock;
    private AlarmManager alarmManager;
    private PendingIntent pendingIntent;
    private final int REQUEST_CODE_SPEECH_INPUT_ADD_TITLE = 101;
    private Spinner sp1;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        setContentView(R.layout.activity_add);
        
        name = findViewById(R.id.add_NameNV);
        date = findViewById(R.id.add_DateNV);
        time = findViewById(R.id.add_TimeNV);
        sp1 = findViewById(R.id.spinner_repeat);
        save = findViewById(R.id.add_savebt);
        cancel = findViewById(R.id.add_cancelbt);
        micTitle = findViewById(R.id.add_micbtTitle);
        calender = findViewById(R.id.all_calender);
        clock = findViewById(R.id.all_clock);


         /*ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            Intent data = result.getData();
                            content.setText(data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).get(0));
                        }
                    }
                }
        );*/

        date.setFocusableInTouchMode(false);
        time.setFocusableInTouchMode(false);

        date.setOnClickListener(this);
        calender.setOnClickListener(this);
        time.setOnClickListener(this);
        clock.setOnClickListener(this);
        cancel.setOnClickListener(this);

        save.setOnClickListener(this);


        micTitle.setOnClickListener(this);
    }
    
    private void promptSpeechInput(int request) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to text");
        try {
            startActivityForResult(intent, request);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(AddActivity.this, " " + a.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CODE_SPEECH_INPUT_ADD_TITLE: {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    name.setText(result.get(0));
                }
                break;
            }
            default:
                throw new IllegalStateException("Unexpected value: " + requestCode);
        }
    }

    @Override
    public void onClick(View v) {
        if(v == date || v == calender) {
            Calendar calendar = Calendar.getInstance();

            int day = calendar.get(Calendar.DAY_OF_MONTH);
            int month = calendar.get(Calendar.MONTH);
            int year = calendar.get(Calendar.YEAR);
            DatePickerDialog dialog = new DatePickerDialog(AddActivity.this,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                            month += 1;
                            date.setText(day + "/" + month + "/" + year);
                        }
                    }, year, month, day);
            dialog.show();
        }
        else if(v == time || v == clock) {
            TimePickerDialog dialog = new TimePickerDialog(AddActivity.this,
                    new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker timePicker,int hourOfDay, int minute) {
                            time.setText(hourOfDay + ":" + minute);
                        }
                    }, 12, 15, false);
            dialog.show();
        }
        else if(v == cancel) {finish();}
        else if(v == save) {
            String namenv = name.getText().toString().trim();
            String datenv = date.getText().toString().trim();
            String timenv = time.getText().toString().trim();
            String spp = null;
            switch (sp1.getSelectedItemPosition()) {
                case 0:
                    spp = "motLanMotTuan";
                    break;
                case 1:
                    spp = "motLanMotTuan26";
                    break;
                case 2:
                    spp = "motLanMotThang";
                    break;
                case 3:
                    spp = "motLanMotNam";
                    break;
            }

            if (namenv.isEmpty())
                Toast.makeText(AddActivity.this, "Yeu cau dien ten", Toast.LENGTH_SHORT).show();
            else {
                SqliteHelper sqlite = new SqliteHelper(getApplicationContext());
                sqlite.add(new NhiemVu(namenv, datenv, timenv, spp));
                Toast.makeText(AddActivity.this, "Them thanh cong! " + spp, Toast.LENGTH_SHORT).show();

                AllFragment.updateUI();
                TodayFragment.updateUI();
                NoDayFragment.updateUI();

//                    sqlite.addReminder(new Reminder())


//                    Calendar calendar = Calendar.getInstance();
//                    String[] st_date =  datenv.split("/");
//                    String[] st_time = timenv.split(":");
//                    calendar.set(Integer.parseInt(st_date[2]), Integer.parseInt(st_date[1]) - 1,
//                            Integer.parseInt(st_date[0]), Integer.parseInt(st_time[0]), Integer.parseInt(st_time[1]));
//
//                    Intent intent = new Intent(AddActivity.this, AlamReceier.class);
//                    intent.setAction("myAction");
//                    intent.putExtra("date", datenv);
//                    intent.putExtra("time", timenv);
//                    intent.putExtra("name", namenv);
//
//                    alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
//                    pendingIntent = PendingIntent.getBroadcast(AddActivity.this, 0,
//                            intent, PendingIntent.FLAG_UPDATE_CURRENT);
//                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);


                finish();
            }


        }
        else if(v == micTitle) {
            promptSpeechInput(REQUEST_CODE_SPEECH_INPUT_ADD_TITLE);
        }
    }
}
package com.example.svmc;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.svmc.fragment.AllFragment;
import com.example.svmc.fragment.NoDayFragment;
import com.example.svmc.fragment.TodayFragment;
import com.example.svmc.model.NhiemVu;
import com.example.svmc.model.Reminder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class AddActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText name;
    private TextView date, time;
    private Button micTitle, calender, clock, bt_rmDate, bt_rmTime;
    private FloatingActionButton save;
    private AlarmManager alarmManager;
    private PendingIntent pendingIntent;
    private final int REQUEST_CODE_SPEECH_INPUT_ADD_TITLE = 101;
    private Spinner sp1;
    private LinearLayout liner_repeat, liner_time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        setContentView(R.layout.activity_add);

        name = findViewById(R.id.add_NameNV);
        date = findViewById(R.id.add_DateNV);
        time = findViewById(R.id.add_TimeNV);
        sp1 = findViewById(R.id.spinner_addrepeat);
        save = findViewById(R.id.buttonAddFab);
        micTitle = findViewById(R.id.add_micbtTitle);
        calender = findViewById(R.id.all_calender);
        clock = findViewById(R.id.all_clock);
        liner_repeat = findViewById(R.id.add_linerRepeat);
        liner_time = findViewById(R.id.add_linerTime);
        bt_rmDate = findViewById(R.id.button_Cancel_Calender);
        bt_rmTime = findViewById(R.id.button_cancel_Time);


         /*ActivityResultLauncher<Intent> activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                            Intent data = result.getData();
                            content.setText(data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS).get(0));
                        }
                    }
                }
        );*/

        liner_time.setVisibility(View.INVISIBLE);
        liner_repeat.setVisibility(View.INVISIBLE);

        date.setFocusableInTouchMode(false);
        time.setFocusableInTouchMode(false);

        date.setOnClickListener(this);
        calender.setOnClickListener(this);
        time.setOnClickListener(this);
        clock.setOnClickListener(this);
        save.setOnClickListener(this);
        micTitle.setOnClickListener(this);
        bt_rmTime.setOnClickListener(this);
        bt_rmDate.setOnClickListener(this);
    }

    private void promptSpeechInput(int request) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to text");
        try {
            startActivityForResult(intent, request);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(AddActivity.this, " " + a.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CODE_SPEECH_INPUT_ADD_TITLE: {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    name.setText(result.get(0));
                }
                break;
            }
            default:
                throw new IllegalStateException("Unexpected value: " + requestCode);
        }
    }

    @Override
    public void onClick(View v) {
        if (v == date || v == calender) {
            Calendar calendar = Calendar.getInstance();

            int dayy = calendar.get(Calendar.DAY_OF_MONTH);
            int monthh = calendar.get(Calendar.MONTH);
            int yearr = calendar.get(Calendar.YEAR);
            DatePickerDialog dialog = new DatePickerDialog(AddActivity.this,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                            month += 1;
                            date.setText(day + "/" + month + "/" + year);
                            liner_time.setVisibility(View.VISIBLE);
                            liner_repeat.setVisibility(View.VISIBLE);
                        }
                    }, yearr, monthh, dayy);
            dialog.show();
        } else if (v == time || v == clock) {
            TimePickerDialog dialog = new TimePickerDialog(AddActivity.this,
                    new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {
                            time.setText(hourOfDay + ":" + minute);
                        }
                    }, 12, 15, false);
            dialog.show();
        } else if (v == save) {
            String namenv, datenv, timenv;
            int repeatnv;
            namenv = name.getText().toString().trim();
            datenv = date.getText().toString().trim();

            timenv = time.getText().toString().trim();
            repeatnv = sp1.getSelectedItemPosition();


            if (namenv.isEmpty())
                Toast.makeText(AddActivity.this, "Yeu cau dien ten" + sp1.getSelectedItemPosition(), Toast.LENGTH_SHORT).show();
            else {
                SqliteHelper sqlite = new SqliteHelper(getApplicationContext());
                sqlite.add(new NhiemVu(namenv, datenv, timenv, repeatnv));
                Toast.makeText(AddActivity.this, "Them thanh cong! ", Toast.LENGTH_SHORT).show();

                AllFragment.updateUI();
                TodayFragment.updateUI();
                NoDayFragment.updateUI();

//                    sqlite.addReminder(new Reminder())


//                    Calendar calendar = Calendar.getInstance();
//                    String[] st_date =  datenv.split("/");
//                    String[] st_time = timenv.split(":");
//                    calendar.set(Integer.parseInt(st_date[2]), Integer.parseInt(st_date[1]) - 1,
//                            Integer.parseInt(st_date[0]), Integer.parseInt(st_time[0]), Integer.parseInt(st_time[1]));
//
//                    Intent intent = new Intent(AddActivity.this, AlamReceier.class);
//                    intent.setAction("myAction");
//                    intent.putExtra("date", datenv);
//                    intent.putExtra("time", timenv);
//                    intent.putExtra("name", namenv);
//
//                    alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
//                    pendingIntent = PendingIntent.getBroadcast(AddActivity.this, 0,
//                            intent, PendingIntent.FLAG_UPDATE_CURRENT);
//                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);


                finish();
            }


        } else if (v == micTitle) {
            promptSpeechInput(REQUEST_CODE_SPEECH_INPUT_ADD_TITLE);
        } else if (v == bt_rmDate) {
            date.setText(null);
            liner_time.setVisibility(View.INVISIBLE);
            liner_repeat.setVisibility(View.INVISIBLE);
        } else if (v == bt_rmTime) {
            time.setText(null);
        }
    }
}
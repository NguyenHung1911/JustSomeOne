package com.example.svmc;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.svmc.Adapter.AdapterNV;
import com.example.svmc.model.NhiemVu;

import java.util.ArrayList;

public class SearchTask extends AsyncTask<CharSequence, CharSequence, Void> {
    private boolean cancled = false;
    private Context context;
    private ArrayList<NhiemVu> list;
    private RecyclerView recyclerView;
    private AdapterNV adapter;
    private TextView tv;


    public SearchTask(Context context, RecyclerView recyclerView, ArrayList<NhiemVu> list, AdapterNV adapter) {
        this.adapter = adapter;
        this.list = list;
        this.context = context;
        this.recyclerView = recyclerView;
    }

    @Override
    protected Void doInBackground(CharSequence... charSequences) {
        String a = "";
        int i = 0;
        while (i < charSequences.length) {
            a += charSequences[i];
        }
        Toast.makeText(context, "chuoi la: " + a, Toast.LENGTH_SHORT).show();
//        if(!this.cancled) {
//            for (int i = 0; i < charSequences.length; i++) {
//                publishProgress(charSequences[i]);
//            }
//        }
        return null;
    }

    @Override
    protected void onPreExecute() {
    }


    @Override
    protected void onPostExecute(Void unused) {
//        adapter = new AdapterNV();
//
//        tv.setText("so nhiem vu: " + list.size());
//        adapter.setList(list);
//        LinearLayoutManager manager = new LinearLayoutManager(context, RecyclerView.VERTICAL, false);
//        recyclerView.setLayoutManager(manager);
//        recyclerView.setHasFixedSize(true);
//        recyclerView.setAdapter(adapter);
        super.onPostExecute(unused);
    }

    @Override
    protected void onProgressUpdate(CharSequence... charSequences) {

//        i = 0;
//        while (i < list.size()) {
//            NhiemVu nv = list.get(i);
//            if(!nv.getName().contains(charSequences[0])) {
//                list.remove(i);
//            }
//            else {
//                i++;
//            }
//        }

    }

    @Override
    protected void onCancelled(Void unused) {
        super.onCancelled(unused);
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
    }

    public void cancel() {
        this.cancled = true;
    }


}

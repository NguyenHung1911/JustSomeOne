package com.example.svmc;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.svmc.fragment.AllFragment;
import com.example.svmc.fragment.TodayFragment;
import com.example.svmc.model.NhiemVu;

import java.util.ArrayList;
import java.util.Locale;

public class UpdateActivity extends AppCompatActivity {
    private EditText editText_name, editText_date, editText_time, editText_content;
    private Button bt_save, bt_cancle, calender, clock, btn_Mic_Title, btn_Mic_Content;
    private final int REQUEST_CODE_SPEECH_INPUT_UPDATE_CONTENT = 100;
    private final int REQUEST_CODE_SPEECH_INPUT_UPDATE_TITLE = 101;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        Intent intent = getIntent();
        NhiemVu nv = (NhiemVu) intent.getExtras().getSerializable("nv");

        editText_name = findViewById(R.id.ud_NameNV);
        editText_date = findViewById(R.id.ud_DateNV);
        editText_time = findViewById(R.id.ud_TimeNV);
        editText_content = findViewById(R.id.ud_ContentNV);
        bt_save = findViewById(R.id.ud_savebt);
        bt_cancle = findViewById(R.id.ud_cancelbt);
        calender = findViewById(R.id.ud_calender);
        clock = findViewById(R.id.ud_clock);
        btn_Mic_Title = findViewById(R.id.ud_micbtTitle);
        btn_Mic_Content = findViewById(R.id.ud_micbtContent);

        editText_date.setEnabled(false);
        editText_time.setEnabled(false);

        editText_name.setText(nv.getName());
        editText_date.setText(nv.getDate());
        editText_time.setText(nv.getTime());
        editText_content.setText(nv.getContent());


        calender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String date = editText_date.getText().toString();
                String [] st = date.split("/");

                int day = Integer.parseInt(st[0]);
                int month = Integer.parseInt(st[1]) - 1;
                int year = Integer.parseInt(st[2]);
                DatePickerDialog dialog = new DatePickerDialog(UpdateActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                month += 1;
                                editText_date.setText(day + "/" + month + "/" + year);
                            }
                        }, year, month, day);
                dialog.show();
            }
        });
        clock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TimePickerDialog dialog = new TimePickerDialog(UpdateActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {
                                editText_time.setText(hourOfDay + ":" + minute);
                            }
                        }, 12, 15, false);
                dialog.show();
            }
        });

        bt_cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editText_name.getText().toString();
                String date = editText_date.getText().toString();
                String time = editText_time.getText().toString();
                String content = editText_content.getText().toString();

                if(name.equals("")) {
                    Toast.makeText(UpdateActivity.this, "Yeu cau nhap ten nghiem vu.", Toast.LENGTH_SHORT).show();
                }
                else {
                    nv.setName(name);
                    nv.setDate(date);
                    nv.setTime(time);
                    nv.setContent(content);

                    SqliteHelper sqlite = new SqliteHelper(getApplicationContext());
                    sqlite.update(nv);
                    AllFragment.updateUI();
                    TodayFragment.updateUI();
                    Toast.makeText(UpdateActivity.this, "update thanh cong!", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });

        btn_Mic_Title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                promptSpeechInput(REQUEST_CODE_SPEECH_INPUT_UPDATE_TITLE);
            }
        });

        btn_Mic_Content.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                promptSpeechInput(REQUEST_CODE_SPEECH_INPUT_UPDATE_CONTENT);
            }
        });

    }

    private void promptSpeechInput(int request) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to text");
        try {
            startActivityForResult(intent, request);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(UpdateActivity.this, " " + a.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_CODE_SPEECH_INPUT_UPDATE_CONTENT: {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    editText_content.setText(result.get(0));
                }
                break;
            }
            case REQUEST_CODE_SPEECH_INPUT_UPDATE_TITLE: {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    editText_name.setText(result.get(0));
                }
                break;
            }
            default:
                throw new IllegalStateException("Unexpected value: " + requestCode);
        }
    }
}
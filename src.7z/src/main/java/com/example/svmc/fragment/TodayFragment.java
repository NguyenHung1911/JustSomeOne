package com.example.svmc.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.svmc.Adapter.AdapterNV;
import com.example.svmc.R;
import com.example.svmc.SqliteHelper;
import com.example.svmc.UpdateActivity;
import com.example.svmc.model.NhiemVu;

import java.util.ArrayList;
import java.util.Calendar;

public class TodayFragment extends Fragment implements AdapterNV.IteamListener {
    private static AdapterNV adapter;
    private static SqliteHelper db;
    private RecyclerView recycler;
    private static ArrayList<NhiemVu> list;
    private static TextView tv, tv_name;
    private static Spinner sp1;
    private static Button btn_search;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_today, container, false);
        tv = view.findViewById(R.id.today_soNv);
        sp1 = view.findViewById(R.id.spinner_todayStatus);
        tv_name = view.findViewById(R.id.today_nameNv);
        btn_search = view.findViewById(R.id.today_btnsearch);

        recycler = view.findViewById(R.id.today_recycleView);
        db = new SqliteHelper(getContext());
        adapter = new AdapterNV();

        String today = whatToday();
        list = getAllList(today);

        tv.setText("so nhiem vu: " + list.size());
        adapter.setList(list);
        LinearLayoutManager manager = new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false);
        recycler.setLayoutManager(manager);
        recycler.setHasFixedSize(true);
        recycler.setAdapter(adapter);

        adapter.setIteamListener(this);
        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String namee = tv_name.getText().toString();
                namee = namee.toUpperCase().trim();
                namee = convert(namee);
                list.clear();
                String today = whatToday();
                list.addAll(getAllList(today));
                if (namee.equals("")) {
                    tv.setText("so nhiem vu: " + list.size());
                    adapter.notifyDataSetChanged();
                } else {
                    ArrayList<NhiemVu> list1 = new ArrayList<>();
                    for (NhiemVu nv : list) {
                        String tmpNv = nv.getName();
                        if (convert(tmpNv).toUpperCase().contains(namee)) {
                            list1.add(nv);
                        }
                    }
                    list.clear();
                    list.addAll(list1);
                    tv.setText("so nhiem vu: " + list.size());
                    tv_name.setText(null);
                    adapter.notifyDataSetChanged();
                }
            }
        });

        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateUI();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        return view;
    }

    @Override
    public void onIteamClick(View view, int pos) {
        Intent intent = new Intent(getActivity(), UpdateActivity.class);
        NhiemVu nv = list.get(pos);
        intent.putExtra("nv", nv);
        startActivity(intent);
    }

    public static void updateUI() {
        list.clear();
        String today = whatToday();
        list.addAll(getAllList(today));
        tv.setText("so nhiem vu: " + list.size());
        adapter.notifyDataSetChanged();

    }

    public static String whatToday() {
        Calendar calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get(Calendar.MONTH) + 1;
        int year = calendar.get(Calendar.YEAR);
        String today = day + "/" + month + "/" + year;
        return today;
    }

    public static ArrayList<NhiemVu> getAllList(String todayy) {
        int status = sp1.getSelectedItemPosition();
        ArrayList<NhiemVu> list2 = new ArrayList<>();
        list2 = db.getAll(todayy);
        ArrayList<NhiemVu> list1 = new ArrayList<>();
        if (status == 0) {
            for (NhiemVu nv : list2) {
                list1.add(nv);
            }

        } else if (status == 1) {
            for (NhiemVu nv : list2) {
                if (nv.getTrangThai() != 0) {
                    list1.add(nv);
                }
            }

        } else if (status == 2) {
            for (NhiemVu nv : list2) {
                if (nv.getTrangThai() == 0) {
                    list1.add(nv);
                }
            }
        }
        return list1;
    }


    public static int TimeToMinute(NhiemVu nvv) {
        String s = nvv.getTime();
        String[] st = s.split(":");
        int res = Integer.parseInt(st[0]) * 60 + Integer.parseInt(st[1]);
        return res;
    }

    public static String convert(String str) {
        str = str.replaceAll("à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ", "a");
        str = str.replaceAll("è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ", "e");
        str = str.replaceAll("ì|í|ị|ỉ|ĩ", "i");
        str = str.replaceAll("ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ", "o");
        str = str.replaceAll("ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ", "u");
        str = str.replaceAll("ỳ|ý|ỵ|ỷ|ỹ", "y");
        str = str.replaceAll("đ", "d");

        str = str.replaceAll("À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ", "A");
        str = str.replaceAll("È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ", "E");
        str = str.replaceAll("Ì|Í|Ị|Ỉ|Ĩ", "I");
        str = str.replaceAll("Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ", "O");
        str = str.replaceAll("Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ", "U");
        str = str.replaceAll("Ỳ|Ý|Ỵ|Ỷ|Ỹ", "Y");
        str = str.replaceAll("Đ", "D");
        return str;
    }
}
